import json 
import re #regular expressions

# Function to read JSON data from a file
def read_json_file(file_path):
    with open(file_path, 'r') as file:
        data = json.load(file)
    return data

# Function to write JSON data to a file
def write_json_file(file_path, data):
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)

# Function to replace text within parentheses with null
def replace_parentheses_with_null(data):
    if isinstance(data, dict):   #checks if the data is dict type or not
        for key in data:
            if isinstance(data[key], str):
                data[key] = re.sub(r'\(.*?\)', '', data[key])
            elif isinstance(data[key], dict) or isinstance(data[key], list):
                data[key] = replace_parentheses_with_null(data[key])
    elif isinstance(data, list):     #checks if the data is list type or not
        for i in range(len(data)):
            if isinstance(data[i], str):
                data[i] = re.sub(r'\(.*?\)', '', data[i])
            elif isinstance(data[i], dict) or isinstance(data[i], list):
                data[i] = replace_parentheses_with_null(data[i])
    return data

# Path to the JSON file #raw string black lash handler
file_path = r'C:\Users\GAD\Downloads\filewriter\college_names.json'

# Read data from the JSON file
data = read_json_file(file_path)

# Replace text within parentheses with null
data = replace_parentheses_with_null(data)

# Write the modified data back to the JSON file
write_json_file(file_path, data)

print("Data has been modified and written to the file.")
