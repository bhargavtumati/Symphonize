from app.helpers import classifier_helper as classifierh
from app.core.config import settings
from google.generativeai import GenerativeModel, configure
import os
import asyncio
from concurrent.futures import ThreadPoolExecutor
from tenacity import retry, wait_fixed, stop_after_attempt

configure(api_key=os.getenv("GEMINI_API_KEY"))
gemini_model = GenerativeModel(os.getenv("GENAI"))

def get_match_score(job_description: str, resume_text: str):
    classifierh.run_once()
    message = job_description + " " + resume_text
    result, probs = classifierh.classify_message(message=message, model_version=settings.CLASSIFIER_VERSION, vectorizer_version=settings.VECTORIZER_VERSION)

    match_score = str(round(probs[classifierh.get_class_key(result)] * 100, 2))
    
    probabilities = []
    
    for i, prob in enumerate(probs):
        probabilities.append(
            {
                "label": classifierh.class_labels[i],
                "probability": round(float(prob), 4)
            }
        )

    match = {
        "result": result,
        "score": match_score,
        "probabilities": probabilities
    }
    
    return match


executor = ThreadPoolExecutor()

@retry(wait=wait_fixed(2), stop=stop_after_attempt(3))    
async def calculate_match_percentage(resume_text, jd_text):
    prompt = f"""
    Analyze the following resume and job description, and calculate the match percentage based on skills, experience, and relevance.
    Resume: {resume_text}
    Job Description: {jd_text}
    Respond with only the match percentage as a whole number ranging from 0 to 100 (e.g., 32 for 32%).
    """
    loop = asyncio.get_event_loop()
    try:
        response = await loop.run_in_executor(executor, gemini_model.generate_content, prompt)
        score = int(response.text.strip())  # 👈 Extract plain integer
        return score
    except Exception as e:
        print(f"Error: {e}")
        return {"error": str(e)}
    
async def process_in_batches(resume_list, jd_text, batch_size=15, delay_seconds=60):
    results = []
    for i in range(0, len(resume_list), batch_size):
        batch = resume_list[i:i + batch_size]
        # Create tasks for the batch
        tasks = [calculate_match_percentage(resume, jd_text) for resume in batch]
        # Await the batch
        batch_results = await asyncio.gather(*tasks)
        results.extend(batch_results)

        # Wait before processing the next batch if there are more resumes
        if i + batch_size < len(resume_list):
            print(f"Sleeping for {delay_seconds} seconds to respect rate limit...")
            await asyncio.sleep(delay_seconds)

    return results

class TokenBucket:
    def __init__(self, rate, interval):
        self.rate = rate  # Number of tokens (calls) allowed
        self.interval = interval  # Interval in seconds (e.g., 60)
        self.semaphore = asyncio.Semaphore(rate)
        self.lock = asyncio.Lock()

        # Start the refill task
        asyncio.create_task(self._refill())

    async def _refill(self):
        while True:
            await asyncio.sleep(self.interval)
            async with self.lock:
                # Refill only the difference (don’t overfill)
                current = self.semaphore._value
                to_add = self.rate - current
                for _ in range(to_add):
                    self.semaphore.release()

    async def acquire(self):
        await self.semaphore.acquire()

# Create the bucket (15 tokens per 60 seconds)
bucket = TokenBucket(rate=15, interval=60)

async def limited_calculate(resume, jd_text):
    await bucket.acquire()
    return await calculate_match_percentage(resume, jd_text)

async def process_with_bucket(resume_list, jd_text):
    tasks = [limited_calculate(resume, jd_text) for resume in resume_list]
    return await asyncio.gather(*tasks)

