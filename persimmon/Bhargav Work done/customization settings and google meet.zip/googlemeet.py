from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from datetime import datetime, timedelta
import pytz

router = APIRouter()

class CreateMeetingRequest(BaseModel):
    token: str
    summary: str
    start_time: str  # Expected format: 'YYYY-MM-DDTHH:MM:SS'
    duration_minutes: int
    time_zone: str  # Time zone (e.g., "Asia/Kolkata", "America/New_York")
    attendees: list[str]

def get_google_service(token: str):
    creds = Credentials(token)
    return build('calendar', 'v3', credentials=creds)

@router.post("/create_meeting")
async def create_meeting(request: CreateMeetingRequest):
    token = request.token
    summary = request.summary
    start_time_str = request.start_time
    duration_minutes = request.duration_minutes
    time_zone = request.time_zone
    attendees = request.attendees

    if not token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    # Convert start_time string to datetime object in the given time zone
    try:
        user_tz = pytz.timezone(time_zone)
        start_time = datetime.strptime(start_time_str, "%Y-%m-%dT%H:%M:%S")
        start_time = user_tz.localize(start_time)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid start_time or time_zone: {str(e)}")

    # Calculate end time
    end_time = start_time + timedelta(minutes=duration_minutes)

    # Convert back to ISO format
    start_time_iso = start_time.strftime("%Y-%m-%dT%H:%M:%S")
    end_time_iso = end_time.strftime("%Y-%m-%dT%H:%M:%S")

    service = get_google_service(token)

    event = {
        'summary': summary,
        'start': {'dateTime': start_time_iso, 'timeZone': time_zone},
        'end': {'dateTime': end_time_iso, 'timeZone': time_zone},
        'attendees': [{'email': email} for email in attendees],
        'conferenceData': {
            'createRequest': {
                'requestId': 'sample123',
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }
    }

    event = service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1,
        sendUpdates='all'
    ).execute()

    return {
        "message": "Meeting created successfully!",
        "meeting_link": event['htmlLink'],
        "start_time": start_time_iso,
        "end_time": end_time_iso,
        "time_zone": time_zone,
        "attendees": attendees
    }

@router.get("/get_meetings")
async def get_meetings(token: str, max_results: int = Query(10, description="Number of meetings to fetch")):
    """
    Fetch upcoming Google Meet events from the user's calendar.
    """
    if not token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    service = get_google_service(token)

    # Get the current time in UTC format
    now = datetime.utcnow().isoformat() + "Z"

    try:
        events_result = service.events().list(
            calendarId='primary',
            timeMin=now,
            maxResults=max_results,
            singleEvents=True,
            orderBy='startTime'
        ).execute()

        events = events_result.get('items', [])

        if not events:
            return {"message": "No upcoming meetings found."}

        meetings = []
        for event in events:
            if "conferenceData" in event and "entryPoints" in event["conferenceData"]:
                meeting_link = next(
                    (entry["uri"] for entry in event["conferenceData"]["entryPoints"] if entry["entryPointType"] == "video"), 
                    "No Google Meet link"
                )
            else:
                meeting_link = "No Google Meet link"

            meetings.append({
                "summary": event.get("summary", "No Title"),
                "start_time": event["start"].get("dateTime", "N/A"),
                "end_time": event["end"].get("dateTime", "N/A"),
                "time_zone": event["start"].get("timeZone", "UTC"),
                "meeting_link": meeting_link
            })

        return {"meetings": meetings}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching meetings: {str(e)}")


class UpdateMeetingRequest(BaseModel):
    token: str
    event_id: str  # The ID of the meeting to update
    summary: str = None
    start_time: str = None  # Expected format: 'YYYY-MM-DDTHH:MM:SS'
    duration_minutes: int = None
    time_zone: str = "UTC"  # Default time zone is UTC
    attendees: list[str] = None
    description: str = None


@router.put("/update_meeting")
async def update_meeting(request: UpdateMeetingRequest):
    """
    Update an existing Google Meet meeting.
    """
    if not request.token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    service = get_google_service(request.token)

    try:
        # Fetch existing event
        event = service.events().get(calendarId='primary', eventId=request.event_id).execute()

        # Update fields only if they are provided
        if request.summary:
            event['summary'] = request.summary

        if request.start_time and request.duration_minutes:
            start_dt = datetime.strptime(request.start_time, "%Y-%m-%dT%H:%M:%S")
            tz = pytz.timezone(request.time_zone)
            start_dt = tz.localize(start_dt)
            end_dt = start_dt + timedelta(minutes=request.duration_minutes)

            event['start'] = {'dateTime': start_dt.isoformat(), 'timeZone': request.time_zone}
            event['end'] = {'dateTime': end_dt.isoformat(), 'timeZone': request.time_zone}

        if request.attendees:
            event['attendees'] = [{'email': email} for email in request.attendees]

        if request.description:
            event['description'] = request.description

        # Update the event
        updated_event = service.events().update(
            calendarId='primary',
            eventId=request.event_id,
            body=event,
            conferenceDataVersion=1
        ).execute()

        return {
            "message": "Meeting updated successfully!",
            "meeting_link": updated_event['htmlLink'],
            "updated_details": {
                "summary": updated_event.get("summary", "No Title"),
                "start_time": updated_event["start"].get("dateTime", "N/A"),
                "end_time": updated_event["end"].get("dateTime", "N/A"),
                "time_zone": updated_event["start"].get("timeZone", "UTC"),
                "attendees": [attendee["email"] for attendee in updated_event.get("attendees", [])]
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating meeting: {str(e)}")












"""from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from pydantic import BaseModel
from typing import List

app = FastAPI()

# Enable CORS (so frontend and backend can communicate)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class CreateMeetingRequest(BaseModel):
    token: str
    attendees: List[str]

def get_google_service(token: str):
    ""Creates a Google Calendar API service with a user’s token""
    creds = Credentials(token=token)
    return build('calendar', 'v3', credentials=creds)

@app.post("/create_meeting")
async def create_meeting(request: CreateMeetingRequest):
    token = request.token
    attendees = request.attendees

    if not token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    service = get_google_service(token)

    event = {
        'summary': 'Meeting with Participants',
        'start': {'dateTime': '2025-01-28T10:00:00Z', 'timeZone': 'UTC'},
        'end': {'dateTime': '2025-01-28T11:00:00Z', 'timeZone': 'UTC'},
        'attendees': [{'email': email} for email in attendees],
        'conferenceData': {
            'createRequest': {
                'requestId': 'sample123',
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }
    }

    event = service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1,
        sendUpdates='all'
    ).execute()

    return {
        "message": "Meeting created successfully!",
        "meeting_link": event['htmlLink'],
        "attendees": attendees
    }
"""






"""from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials

app = FastAPI()

# Enable CORS (so frontend and backend can communicate)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # React frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def get_google_service(token: str):
    ""Creates a Google Calendar API service with a user’s token""
    creds = Credentials(token=token)
    return build('calendar', 'v3', credentials=creds)

@app.post("/create_meeting")
async def create_meeting(request: Request):
    data = await request.json()
    token = data.get("token")
    attendees = data.get("attendees", [])

    if not token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    service = get_google_service(token)

    event = {
        'summary': 'Meeting with Participants',
        'start': {'dateTime': '2025-01-28T10:00:00Z', 'timeZone': 'UTC'},
        'end': {'dateTime': '2025-01-28T11:00:00Z', 'timeZone': 'UTC'},
        'attendees': [{'email': email} for email in attendees],
        'conferenceData': {
            'createRequest': {
                'requestId': 'sample123',
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }
    }

    event = service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1,
        sendUpdates='all'
    ).execute()

    return {
        "message": "Meeting created successfully!",
        "meeting_link": event['htmlLink'],
        "attendees": attendees
    }
"""