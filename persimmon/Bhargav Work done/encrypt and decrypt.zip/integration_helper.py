# Encryption Function (for generating encrypted tokens)

from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from base64 import b64decode, b64encode
import os
import hashlib


# Environment Setup (use a strong secret in production!)
SECRET_KEY_RAW = os.getenv("ENCRYPTION_SECRET", "your-very-secret-key")
SECRET_KEY = hashlib.sha256(SECRET_KEY_RAW.encode()).digest()  # AES key derived from SHA-256
def encrypt_token(plain_text: str) -> str:
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(plain_text.encode()) + padder.finalize()

    # Generate a random IV for each encryption
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(SECRET_KEY), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted_data = encryptor.update(padded_data) + encryptor.finalize()

    # Include the IV with the encrypted data
    return b64encode(iv + encrypted_data).decode()


# Decryption Function (for decrypting encrypted tokens)
def decrypt_token(encrypted_token_base64: str) -> str:
    encrypted_token = b64decode(encrypted_token_base64)

    # Extract the IV from the encrypted data
    iv = encrypted_token[:16]
    encrypted_data = encrypted_token[16:]
   
    cipher = Cipher(algorithms.AES(SECRET_KEY), modes.CFB(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted_padded = decryptor.update(encrypted_data) + decryptor.finalize()

    # Remove PKCS7 padding
    unpadder = padding.PKCS7(128).unpadder()
    decrypted = unpadder.update(decrypted_padded) + unpadder.finalize()

    return decrypted.decode()