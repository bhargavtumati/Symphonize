import httpx
from datetime import datetime, timezone, timedelta
from app.helpers import db_helper as dbh
from sqlalchemy.orm import Session
from fastapi import HTTPException, Query
from pydantic import BaseModel
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from datetime import datetime, timedelta
import pytz

GOOGLE_REDIRECT_URI = "http://localhost:3000/oauth-callback"
GOOGLE_CLIENT_ID = "793571778940-361uq4isbu25oh0on9rci3fpieb6ektn.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET = "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"

def get_tokens_from_auth_code(code: str):
    url = "https://oauth2.googleapis.com/token"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "code": code,
        "client_id": GOOGLE_CLIENT_ID,
        "client_secret": GOOGLE_CLIENT_SECRET,
        "redirect_uri": GOOGLE_REDIRECT_URI,
        "grant_type": "authorization_code"
    }

    response = httpx.post(url, data=data, headers=headers)
    return response.json()


def refresh_google_access_token(google_refresh_token: str=None):
     token_url = "https://oauth2.googleapis.com/token"
     headers = {"Content-Type": "application/x-www-form-urlencoded"}

     data = {
         "client_id": GOOGLE_CLIENT_ID,
         "client_secret": GOOGLE_CLIENT_SECRET,
         "refresh_token": google_refresh_token,
         "grant_type": "refresh_token"
     }

     response = httpx.post(token_url, data=data, headers=headers)
     return response.json()

def validate_access_token(credentials,integration,email,session: Session):
    if credentials.get('expires_in') < datetime.now(timezone.utc).isoformat():
        response = refresh_google_access_token(credentials['refresh_token'])
        expires_in = datetime.now(timezone.utc) + timedelta(seconds=response.get('expires_in'))
        expires_in = expires_in.isoformat()
        credentials = {
            "refresh_token": response.get('refresh_token'),
            "access_token": response.get('access_token'),
            "expires_in": expires_in
        }
        integration.credentials.update(credentials)
        integration.meta.update(dbh.update_meta(meta=integration.meta, email=email))
        integration.update(session=session)
    else:
        response = credentials
    return response

class CreateGoogleMeetingRequest(BaseModel):
    token: str
    summary: str
    start_time: str  # Expected format: 'YYYY-MM-DDTHH:MM:SS'
    duration_minutes: int
    time_zone: str  # Time zone (e.g., "Asia/Kolkata", "America/New_York")
    attendees: list[str]

def get_google_service(token: str):
    creds = Credentials(token)
    return build('calendar', 'v3', credentials=creds)

async def create_meeting(request: CreateGoogleMeetingRequest):
    token = request.token
    summary = request.summary
    start_time_str = request.start_time
    duration_minutes = request.duration_minutes
    time_zone = request.time_zone
    attendees = request.attendees

    if not token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    # Convert start_time string to datetime object in the given time zone
    try:
        user_tz = pytz.timezone(time_zone)
        start_time = datetime.strptime(start_time_str, "%Y-%m-%dT%H:%M:%S")
        start_time = user_tz.localize(start_time)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid start_time or time_zone: {str(e)}")

    # Calculate end time
    end_time = start_time + timedelta(minutes=duration_minutes)

    # Convert back to ISO format
    start_time_iso = start_time.strftime("%Y-%m-%dT%H:%M:%S")
    end_time_iso = end_time.strftime("%Y-%m-%dT%H:%M:%S")

    service = get_google_service(token)

    event = {
        'summary': summary,
        'start': {'dateTime': start_time_iso, 'timeZone': time_zone},
        'end': {'dateTime': end_time_iso, 'timeZone': time_zone},
        'attendees': [{'email': email} for email in attendees],
        'conferenceData': {
            'createRequest': {
                'requestId': 'sample123',
                'conferenceSolutionKey': {'type': 'hangoutsMeet'}
            }
        }
    }

    event = service.events().insert(
        calendarId='primary',
        body=event,
        conferenceDataVersion=1,
        sendUpdates='all'
    ).execute()

    return {
        "message": "Meeting created successfully!",
        "meeting_link": event['htmlLink'],
        "start_time": start_time_iso,
        "end_time": end_time_iso,
        "time_zone": time_zone,
        "attendees": attendees
    }


async def get_meetings(token: str, max_results: int = Query(10, description="Number of meetings to fetch")):
    """
    Fetch upcoming Google Meet events from the user's calendar.
    """
    if not token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    service = get_google_service(token)

    # Get the current time in UTC format
    now = datetime.now(timezone.utc).isoformat()

    try:
        events_result = service.events().list(
            calendarId='primary',
            timeMin=now,
            maxResults=max_results,
            singleEvents=True,
            orderBy='startTime'
        ).execute()

        events = events_result.get('items', [])

        if not events:
            return {"message": "No upcoming meetings found."}

        meetings = []
        for event in events:
            if "conferenceData" in event and "entryPoints" in event["conferenceData"]:
                meeting_link = next(
                    (entry["uri"] for entry in event["conferenceData"]["entryPoints"] if entry["entryPointType"] == "video"), 
                    "No Google Meet link"
                )
            else:
                meeting_link = "No Google Meet link"

            meetings.append({
                "summary": event.get("summary", "No Title"),
                "start_time": event["start"].get("dateTime", "N/A"),
                "end_time": event["end"].get("dateTime", "N/A"),
                "time_zone": event["start"].get("timeZone", "UTC"),
                "meeting_link": meeting_link
            })

        return {"meetings": meetings}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error fetching meetings: {str(e)}")


class UpdateGoogleMeetingRequest(BaseModel):
    token: str
    event_id: str  # The ID of the meeting to update
    summary: str = None
    start_time: str = None  # Expected format: 'YYYY-MM-DDTHH:MM:SS'
    duration_minutes: int = None
    time_zone: str = "UTC"  # Default time zone is UTC
    attendees: list[str] = None
    description: str = None

async def update_meeting(request: UpdateGoogleMeetingRequest):
    """
    Update an existing Google Meet meeting.
    """
    if not request.token:
        raise HTTPException(status_code=400, detail="OAuth token is required")

    service = get_google_service(request.token)

    try:
        # Fetch existing event
        event = service.events().get(calendarId='primary', eventId=request.event_id).execute()

        # Update fields only if they are provided
        if request.summary:
            event['summary'] = request.summary

        if request.start_time and request.duration_minutes:
            start_dt = datetime.strptime(request.start_time, "%Y-%m-%dT%H:%M:%S")
            tz = pytz.timezone(request.time_zone)
            start_dt = tz.localize(start_dt)
            end_dt = start_dt + timedelta(minutes=request.duration_minutes)

            event['start'] = {'dateTime': start_dt.isoformat(), 'timeZone': request.time_zone}
            event['end'] = {'dateTime': end_dt.isoformat(), 'timeZone': request.time_zone}

        if request.attendees:
            event['attendees'] = [{'email': email} for email in request.attendees]

        if request.description:
            event['description'] = request.description

        # Update the event
        updated_event = service.events().update(
            calendarId='primary',
            eventId=request.event_id,
            body=event,
            conferenceDataVersion=1
        ).execute()

        return {
            "message": "Meeting updated successfully!",
            "meeting_link": updated_event['htmlLink'],
            "updated_details": {
                "summary": updated_event.get("summary", "No Title"),
                "start_time": updated_event["start"].get("dateTime", "N/A"),
                "end_time": updated_event["end"].get("dateTime", "N/A"),
                "time_zone": updated_event["start"].get("timeZone", "UTC"),
                "attendees": [attendee["email"] for attendee in updated_event.get("attendees", [])]
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error updating meeting: {str(e)}")