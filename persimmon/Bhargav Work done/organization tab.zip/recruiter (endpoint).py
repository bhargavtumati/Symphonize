import os
from typing import Optional,List
from fastapi import APIRouter, File, UploadFile, status
from fastapi import Depends, HTTPException, Form
from app.models.company import Company
from app.models.template import Template
from app.models.recruiter import Recruiter
from app.models.company import Company,CompanyTypeEnum,BusinessTypeEnum
from app.api.v1.endpoints.models.company_model import CompanyModel
from app.api.v1.endpoints.models.recruiter_model import RecruiterModel
from app.helpers.firebase_helper import verify_firebase_token
from app.helpers.regex_helper import get_domain_from_email
from app.helpers.image_helper import binary_to_base64
import app.helpers.email_helper as emailh
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from sqlalchemy import CursorResult
from app.db.session import get_db

router = APIRouter()

meta: dict[str, str] = {"api_reference": "https://github.com/symphonize/persimmon-api"}

@router.post("")
async def create_recruiter_endpoint( 
    full_name: str = Form(...),
    whatsapp_number: str = Form(...),
    designation: str = Form(...),
    linkedin_url: str = Form(...),
    email_id: str = Form(...),
    company_name: str = Form(...),
    website: str = Form(...),  
    profile_image: Optional[UploadFile] = File(None),
    number_of_employees: str = Form(...),
    industry_type: str = Form(...),
    company_type: CompanyTypeEnum = Form(...),
    company_linkedin_url: str = Form(...),
    tagline: Optional[str] = Form(None),  # ✅ NULL instead of empty string
    business_type: Optional[BusinessTypeEnum] = Form(None),
    about: Optional[str] = Form(None),
    instagram_url: Optional[str] = Form(None),
    facebook_url: Optional[str] = Form(None),
    x_url: Optional[str] = Form(None),
    logo: Optional[UploadFile] = File(None),
    company_images: Optional[List[UploadFile]] = File(None),
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
):
    try:
        # Check if recruiter already exists by WhatsApp number
        existing_recruiter = Recruiter.get_by_whatsapp_number(session=session, whatsapp_number=whatsapp_number)
        if existing_recruiter:
            raise HTTPException(status_code=409, detail="This WhatsApp number is already registered. Please use a different number")

        email_domain = get_domain_from_email(email_id)
        company_record = Company.get_by_domain(session=session, domain=email_domain)
        created_by = token['email']
        try:
            
            validated_company = CompanyModel(
                name = company_name,
                website= website,
                number_of_employees= number_of_employees,
                industry_type= industry_type,
                company_type= company_type.value,
                tagline= tagline,
                business_type= business_type.value,
                about= about,
                linkedin_url= company_linkedin_url,
                instagram_url= instagram_url,
                facebook_url= facebook_url,
                x_url= x_url,
                logo= logo,
                company_images= company_images
            )
            validated_recruiter = RecruiterModel(
                full_name=full_name,
                whatsapp_number=whatsapp_number,
                designation=designation,
                linkedin_url=linkedin_url,
                email_id=email_id,
                profile_image=profile_image,
                company=validated_company  
            )
        except ValueError as e:
               raise HTTPException(status_code=422, detail=str(e))

        logo_bytes = company_images_bytes = profile_image_bytes =  None
        if logo:
            logo_bytes = logo.file.read() if logo else None  
        if profile_image:
            profile_image_bytes = profile_image.file.read() if profile_image else None 
        # Validate and process company images
        if company_images:
            company_images_bytes = [image.file.read() for image in company_images] if company_images else None  

        if company_record:
            company_id = company_record.id
        else:
            company_data = Company(
                name=company_name,
                website=website,
                number_of_employees=number_of_employees,
                industry_type=industry_type,
                company_type=company_type,
                tagline=tagline,
                business_type=business_type,
                about=about,
                linkedin_url=company_linkedin_url,
                instagram_url=instagram_url,
                facebook_url=facebook_url,
                x_url=x_url,
                domain=email_domain,
                logo=logo_bytes,
                company_images=company_images_bytes
            )
            company_record = company_data.create(session=session, created_by=created_by)
            company_id = company_record.id

            # Create email template for new company
            email_id = os.getenv("TEMPLATE_EMAIL_ID")
            email_template = Template(company_id=company_record.id, template_data=emailh.get_email_templates(), email_id=email_id)
            email_template.create(session=session, created_by=created_by)

        recruiter_data = Recruiter(
            full_name=full_name,
            whatsapp_number=whatsapp_number,
            designation=designation,
            linkedin_url=linkedin_url,
            email_id=email_id,
            profile_image=profile_image_bytes,
            company_id=company_id
        )

        recruiter_record = recruiter_data.create(session=session, created_by=created_by)

        return {
            "message": "Recruiter created successfully",
            "data": recruiter_record,
            "status": 201
        }

    except HTTPException as e:
        raise e
    except IntegrityError as e:
        if "duplicate key value violates unique constraint" in str(e.orig):
            raise HTTPException(status_code=409, detail="Email already exists, please provide a new Email ID")
        else:
            raise HTTPException(status_code=500, detail="Database error occurred.")
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
@router.put("/{recruiter_id}")
async def update_recruiter_endpoint(
    recruiter_id : int,
    full_name: str = Form(...),
    whatsapp_number: str = Form(...),
    designation: str = Form(...),
    linkedin_url: str = Form(...),
    email_id: str = Form(...),
    company_name: str = Form(...),
    website: str = Form(...),  
    number_of_employees: str = Form(...),
    industry_type: str = Form(...), 
    company_linkedin_url: str = Form(...),
    profile_image: Optional[UploadFile] = File(None),
    company_type: CompanyTypeEnum = Form(...),   
    tagline: Optional[str] = Form(None),     # ✅ NULL instead of empty string
    business_type: Optional[BusinessTypeEnum] = Form(None),
    about: Optional[str] = Form(None),
    instagram_url: Optional[str] = Form(None),
    facebook_url: Optional[str] = Form(None),
    x_url: Optional[str] = Form(None),
    logo: Optional[UploadFile] = File(None),
    company_images: Optional[List[UploadFile]] = File(None),
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
):
    try:
        recruiter = session.query(Recruiter).filter(Recruiter.id == recruiter_id).first()
        if not recruiter:
            raise HTTPException(status_code=404, detail="Recruiter not found")
        
        # Check if WhatsApp number exists for another recruiter
        if whatsapp_number and whatsapp_number != recruiter.whatsapp_number:
            existing_recruiter = Recruiter.get_by_whatsapp_number(session=session, whatsapp_number=whatsapp_number)
            if existing_recruiter:
                raise HTTPException(status_code=409, detail="This WhatsApp number is already registered. Please use a different number")

        if email_id and email_id != recruiter.email_id:
            email_domain = get_domain_from_email(email_id)
            company_record = Company.get_by_domain(session=session, domain=email_domain)
            recruiter.email_id = email_id
        else:
            email_domain = get_domain_from_email(recruiter.email_id)
            company_record = Company.get_by_domain(session=session, domain=email_domain)

        try:
            validated_company = CompanyModel(
                name = company_name,
                website= website,
                number_of_employees= number_of_employees,
                industry_type= industry_type,
                company_type= company_type.value,
                tagline= tagline,
                business_type= business_type.value,
                about= about,
                linkedin_url= company_linkedin_url,
                instagram_url= instagram_url,
                facebook_url= facebook_url,
                x_url= x_url,
                logo= logo,
                company_images= company_images
            )
            validated_recruiter = RecruiterModel(
                full_name=full_name,
                whatsapp_number=whatsapp_number,
                designation=designation,
                linkedin_url=linkedin_url,
                email_id=email_id,
                profile_image= profile_image,
                company=validated_company  
            )
        except ValueError as e:
               raise HTTPException(status_code=422, detail=str(e))

        logo_bytes = company_images_bytes = profile_image_bytes = None
        if logo:
            logo_bytes = logo.file.read() if logo else None  
      
        # Validate and process company images
        if company_images:
            company_images_bytes = [image.file.read() for image in company_images] if company_images else None   

        if profile_image:
            profile_image_bytes = await profile_image.file.read() if logo else None  

        # Update recruiter details
        recruiter.full_name = full_name 
        recruiter.whatsapp_number = whatsapp_number 
        recruiter.designation = designation 
        recruiter.linkedin_url = linkedin_url 
        recruiter.company_id = recruiter.company_id
        recruiter.profile_image = profile_image_bytes

        company_record = session.query(Company).filter_by(domain=email_domain).first()

        company_record.name = company_name
        company_record.website = website
        company_record.number_of_employees = number_of_employees
        company_record.industry_type = industry_type
        company_record.company_type = company_type
        company_record.tagline = tagline
        company_record.business_type = business_type
        company_record.about = about
        company_record.linkedin_url = company_linkedin_url
        company_record.instagram_url = instagram_url
        company_record.facebook_url = facebook_url
        company_record.x_url = x_url
        company_record.logo = logo_bytes 
        company_record.company_images = company_images_bytes
       
        session.commit()
        recruiter_data = {
            "full_name": recruiter.full_name,
            "whatsapp_number": recruiter.whatsapp_number,
            "designation": recruiter.designation,
            "linkedin_url": recruiter.linkedin_url,
            "email_id" : recruiter.email_id
        }
        return {
            "message": "Recruiter updated successfully",
            "data": recruiter_data,
            "status": 200
        }
    except HTTPException as e:
        session.rollback()
        raise e
    except IntegrityError as e:
        session.rollback()
        if "duplicate key value violates unique constraint" in str(e.orig):
            raise HTTPException(status_code=409, detail="Email already exists, please provide a new Email ID")
        else:
            raise HTTPException(status_code=500, detail="Database error occurred.")
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
"""
@router.post("")
async def create_recruiter_endpoint( 
    recruiter: RecruiterModel, 
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
):
    try:
        existing_recruiter = Recruiter.get_by_whatsapp_number(session=session, whatsapp_number=recruiter.whatsapp_number)
        if existing_recruiter:
            raise ValueError("WhatsAppNumberExists")
        
        email_domain = get_domain_from_email(recruiter.email_id)

        company_record = Company.get_by_domain(session=session, domain=email_domain)
        created_by = token['email']
        if company_record:
            company_id = company_record.id
        else:
            company_data = Company(**recruiter.company.model_dump())
            company_data.domain = email_domain
            company_record = company_data.create(session=session, created_by=created_by)
            company_id = company_record.id
            email_id = os.getenv("TEMPLATE_EMAIL_ID")
            email_data = {
                "id": email_id,
                "send_count": 0
            }
            email_template = Template(company_id = company_record.id, template_data = emailh.get_email_templates(), email_data = email_data)
            email_template.create(session=session, created_by=created_by)

        recruiter_data = Recruiter(
            full_name=recruiter.full_name,
            whatsapp_number=recruiter.whatsapp_number,
            designation=recruiter.designation,
            linkedin_url=recruiter.linkedin_url,
            email_id=recruiter.email_id,  # Ensure this matches the field in your Recruiter model
            company_id=company_id
        )
        
        recruiter_record = recruiter_data.create(session=session, created_by=created_by)
        return {
            "message": "Recruiter created successfully",
            "data": recruiter_record,
            "status": status.HTTP_201_CREATED
        }

    except ValueError as e:
        if str(e) == "WhatsAppNumberExists":
            raise HTTPException(status_code=409, detail="This WhatsApp number is already registered. Please use a different number")
    
    except IntegrityError as e:
        # Check if the error is related to unique constraint violation
        if "duplicate key value violates unique constraint" in str(e.orig):
            raise HTTPException(status_code=409, detail="Email already exists, please provide a new Email ID")
        else:
            raise HTTPException(status_code=500, detail="Database error occurred.")
            
    except HTTPException as e:
        raise e 
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
"""

@router.get('/{email_id}')
def verify_recruiter_by_email(
    email_id: str,
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
    ):
    try:
        exists = Recruiter.exists_by_email_id(session=session, email=email_id)
        return exists
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@router.get("")
def get_recruiter(
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
) -> dict:
    email_id = token['email']
    try:
        recruiter = Recruiter.get_by_created_by_email(session=session, email=email_id)
        if not recruiter:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Recuriter not found.")
        
        recruiter_data = {
            "full_name": recruiter.full_name,
            "whatsapp_number": recruiter.whatsapp_number,
            "designation": recruiter.designation,
            "linkedin_url": recruiter.linkedin_url,
            "email_id" : recruiter.email_id,
            "profile_image": binary_to_base64(recruiter.profile_image) if recruiter.profile_image else None
        }
        return {
            "message": "Recruiter fetched successfully",
            "recruiter": recruiter_data,
            "status": status.HTTP_200_OK
        }
    except HTTPException as e:
        return e
    except Exception as e:
        return HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error during database call {str(e)}")
    #return create_response(message=f"Get all recruiters", data=data, meta=meta)

"""
@router.patch("/update")
async def update_recruiter( 
    recruiter: UpdateRecruiterModel, 
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
):
    try:
        existing_recruiter: Recruiter = Recruiter.get_by_created_by_email(session=session, email=token["email"])
        if not existing_recruiter:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recruiter not found.")

        if existing_recruiter.whatsapp_number != recruiter.whatsapp_number:
            if Recruiter.get_by_whatsapp_number(session=session, whatsapp_number=recruiter.whatsapp_number):
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="WhatsApp number already exists.")

        existing_recruiter.full_name = recruiter.full_name
        existing_recruiter.whatsapp_number = recruiter.whatsapp_number
        existing_recruiter.designation = recruiter.designation
        existing_recruiter.linkedin_url = recruiter.linkedin_url
        existing_recruiter.update(session)
        return {
            "message": "Recruiter details updated successfully",
            "status": status.HTTP_200_OK
        }
    except HTTPException as e:
        raise e 
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
"""
@router.post("/profile/image")
async def update_recruiter_profile_image(
    file: UploadFile = File(...),
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
):
    try:
        if file.content_type not in ["image/jpeg", "image/png"]:
            raise HTTPException(status_code=400, detail="Only JPEG and PNG images are allowed")
        contents = await file.read()
        if len(contents) > 2 * 1024 * 1024: 
            raise HTTPException(status_code=400, detail="File size exceeds 2MB")
        cursor_result: CursorResult = Recruiter.update_profile_image(session=session, email=token['email'], image=contents)
        if cursor_result.rowcount == 0:
            raise HTTPException(status_code=404, detail=f"recruiter not found")
        return {"message": "Image uploaded successfully"}
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during database call {str(e)}")
    

@router.get("/profile/image")
def get_recruiter_profile_image(
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db)
):
    email_id = token['email']
    try:
        recruiter = Recruiter.get_by_created_by_email(session=session, email=email_id)
        if not recruiter:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Recuriter not found.")
        if not recruiter.profile_image:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"profile image not found")
        return {
            "status":200,
            "message":"Recruiter profile image retrived successfully",
            "profile_image": binary_to_base64(recruiter.profile_image)
        }
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error during database call {str(e)}")
    