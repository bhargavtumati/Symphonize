

import requests
from fastapi import APIRouter, HTTPException, status, Depends, FastAPI
from fastapi.security import OAuth2AuthorizationCodeBearer
from pydantic import BaseModel
from dotenv import load_dotenv
import os

load_dotenv()

CLIENT_ID = os.getenv("CISWEBX_CLIENT_ID")
CLIENT_SECRET = os.getenv("CISWEBX_CLIENT_SECRET")
REDIRECT_URI = os.getenv("CISWEBX_REDIRECT_URI")
AUTH_URL = os.getenv("CISWEBX_AUTH_URL")
TOKEN_URL = os.getenv("CISWEBX_TOKEN_URL")

app = FastAPI()

oauth2_scheme = OAuth2AuthorizationCodeBearer(
    authorizationUrl=AUTH_URL,
    tokenUrl=TOKEN_URL,
)

class MeetingRequest(BaseModel):
    title: str
    start: str
    end: str
    recruiter_email: str
    applicant_email: str

router = APIRouter()

@router.get("/auth")
def authorize():
    auth_url = f"{AUTH_URL}?client_id={CLIENT_ID}&response_type=code&redirect_uri={REDIRECT_URI}"
    return {"auth_url": auth_url}

@router.get("/callback")
def callback(code: str):
    response = requests.post(
        TOKEN_URL,
        data={
            "grant_type": "authorization_code",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
            "code": code,
            "redirect_uri": REDIRECT_URI,
        },
    )
    tokens = response.json()
    return tokens

def get_token(token: str = Depends(oauth2_scheme)):
    return token

@router.post("/create_meeting")
def create_meeting(meeting_request: MeetingRequest, token: str = Depends(get_token)):
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    meeting_data = {
        "title": meeting_request.title,
        "start": meeting_request.start,
        "end": meeting_request.end,
        "invitees": [
            {"email": meeting_request.recruiter_email},
            {"email": meeting_request.applicant_email}
        ],
        "enabledAutoLock": True,
        "autoLockMinutes": 0,
        "enabledJoinBeforeHost": False,
        "inviteeRestrictions": "inviteOnly",
    }
    response = requests.post(
        "https://webexapis.com/v1/meetings",
        headers=headers,
        json=meeting_data,
    )
    if response.status_code != 200:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=response.json(),
        )
    return response.json()




