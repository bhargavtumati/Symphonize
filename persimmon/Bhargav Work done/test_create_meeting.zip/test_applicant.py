from unittest.mock import patch, MagicMock, AsyncMock
from fastapi.testclient import TestClient
from httpx import AsyncClient
from app.main import app
import pytest
from uuid import uuid4
from datetime import datetime, timedelta, timezone
from app.helpers.firebase_helper import verify_firebase_token
from app.models.applicant import InterviewType

client = TestClient(app)

def mock_verify_firebase_token():
    return {
        "user_id": "111",
        "email": "surendra.goluguri@symphonize.com"
    }

app.dependency_overrides[verify_firebase_token] = mock_verify_firebase_token


@patch("app.api.v1.endpoints.jobs.Job.get_by_id")
@patch("app.api.v1.endpoints.jobs.Stages.get_by_id")
@patch("app.api.v1.endpoints.jobs.Applicant.get_by_uuid")
@patch("app.helpers.solr_helper.update_solr_documents_partially")
def test_partial_update_success(
    mock_solr_update,
    mock_get_applicant,
    mock_get_stages,
    mock_get_job,
):
    # Mock job retrieval
    mock_get_job.return_value = MagicMock()
    
    # Mock stages retrieval
    mock_get_stages.return_value = MagicMock(
        stages=[
            {"uuid": "52795e02-13e4-4452-9322-715001c58ff7", "name": "interview"},
            {"uuid": "7f32cc9e-e5fb-4cfb-9ae7-32e8d13648d1", "name": "hired"}
        ]
    )
    
    # Mock applicant retrieval
    mock_applicant = MagicMock()
    mock_get_applicant.return_value = mock_applicant
    
    # Mock Solr update success
    mock_solr_update.return_value = None
    
    payload = {
        "applicant_uuids": ["fbc5589e-9931-4d60-87ec-0c38bfd9c4e1"],
        "stage_uuid": "7f32cc9e-e5fb-4cfb-9ae7-32e8d13648d1"
    }
    
    response = client.patch("/api/v1/applicants?job_id=1", json=payload)
    
    assert response.status_code == 200
    assert response.json()["message"] == "Successfully moved to hired"

@patch("app.api.v1.endpoints.jobs.Job.get_by_id", return_value=None)
def test_partial_update_job_not_found(mock_get_job):
    payload = {
        "applicant_uuids": ["fbc5589e-9931-4d60-87ec-0c38bfd9c4e1"],
        "stage_uuid": "7f32cc9e-e5fb-4cfb-9ae7-32e8d13648d1"
    }
    
    response = client.patch("/api/v1/applicants?job_id=1", json=payload)
    
    assert response.status_code == 404
    assert response.json()["detail"] == "Job not found"

@patch("app.api.v1.endpoints.jobs.Stages.get_by_id")   #give the method to MajicMock- 
@patch("app.api.v1.endpoints.jobs.Job.get_by_id")      
@patch("app.api.v1.endpoints.jobs.Applicant.get_by_uuid")
@patch("app.helpers.solr_helper.update_solr_documents_partially")
def test_partial_update_invalid_stage( mock_solr_update,
    mock_get_applicant,
    mock_get_stages,            
    mock_get_job):   #majic mock will give mock stages, applicants and they are passed to the test method
    payload = {
        "applicant_uuids": ["fbc5589e-9931-4d60-87ec-0c38bfd9c4e1"],
        "stage_uuid": "ee6ec4f0-b47c-4748-92c6-97ace111a725"
    }
    
    response = client.patch("/api/v1/applicants?job_id=1", json=payload)    #call the endpoint by giving necessary params
    
    assert response.status_code == 400
    assert response.json()["detail"] == "Invalid stage uuid"    #test is passed if expected result is same like what is expected

@pytest.fixture
def mock_applicant():
    mock = MagicMock()
    mock.feedback = [
        {
        "rating": {"skill": 3, "communication": 3, "professionalism": 3},
        "overall_feedback": "string",
        "opinion": "dislike",
        "given_by": "user1@example.com"
         }
    ]
    return mock

def get_valid_feedback():
    return {
        "feedback": [
            {
            "rating": {
                "skill": 3,
                "communication": 5,
                "professionalism": 4
            },
            "overall_feedback": "verry good knowledge on python and having excellent knowledge on spring boot and microservices",
            "opinion": "DISLIKE",
            "given_by": "developer@tekworks.in"
            }
        ]
    }

@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid", return_value=None)
def test_add_feedback_applicant_not_found(mock_get_applicant):
    payload = get_valid_feedback()
    response = client.post("/api/v1/applicants/fbc5589e-9931-4d60-87ec-0c38bfd9c4e1/feedback", json=payload)
    assert response.status_code == 404
    assert response.json()["detail"] == "Applicant not found"

@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid")
def test_add_feedback_invalid_feedback_format(mock_get_applicant, mock_applicant):
    mock_get_applicant.return_value = mock_applicant

    response = client.post("/api/v1/applicants/fbc5589e-9931-4d60-87ec-0c38bfd9c4e1/feedback", json={"feedback": {}})
    assert response.status_code == 422

@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid")
def test_add_feedback_success(mock_get_applicant, mock_applicant):
    mock_get_applicant.return_value = mock_applicant
    payload = get_valid_feedback()
    response = client.post("/api/v1/applicants/fbc5589e-9931-4d60-87ec-0c38bfd9c4e1/feedback", json=payload)
    assert response.status_code == 200
    assert response.json()["status"] == "success"
    assert response.json()["message"] == "Feedback updated successfully"

@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid")
def test_add_feedback_db_error(mock_get_applicant, mock_applicant):
    mock_get_applicant.return_value = mock_applicant
    mock_applicant.update.side_effect = Exception("Database error")
    payload = get_valid_feedback()
    response = client.post("/api/v1/applicants/fbc5589e-9931-4d60-87ec-0c38bfd9c4e1/feedback", json=payload)
    assert response.status_code == 500
    assert "Unexpected Error" in response.json()["detail"]




@pytest.mark.asyncio
@patch("app.helpers.email_helper.sendgrid_send_mail", return_value={"message":"Email sent successfully"})
@patch("app.helpers.email_helper.get_sendgrid_senders", return_value=["admin@persimmon.com"])
@patch("app.helpers.firebase_helper.verify_firebase_token", return_value={"email": "recruiter@example.com"})
@patch("app.db.session.get_db")
@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid")
@patch("app.models.company.Company.get_by_domain")
@patch("app.helpers.zoom_helper.create_meeting")
@patch("app.helpers.zoom_helper.validate_access_token")
@patch("app.helpers.email_helper.send_email", return_value="Email sent successfully")
@patch("app.helpers.regex_helper.get_domain_from_email", return_value="company.com")
@patch("app.helpers.date_helper.validate_future_datetime")
@patch("app.helpers.date_helper.calculate_duration_in_minutes", return_value=30)
@patch("app.models.integration.Integration.get_credentials")
@patch("app.models.template.Template.get_by_company_id")
async def test_create_zoom_meeting_success(    
        mock_template,
        mock_integration,
        mock_duration,
        mock_date_validate,
        mock_domain,
        mock_send_email,
        mock_validate_access,
        mock_create_meeting,
        mock_company,
        mock_applicant,
        mock_get_db,
        mock_token,
        mock_senders,
        mock_sendgrid
    ) :
    # Setup test UUID
    applicant_uuid = uuid4()

    # Setup mock DB session
    mock_db = MagicMock()
    mock_get_db.return_value = iter([mock_db])

    # Company mock
    mock_company_instance = MagicMock()
    mock_company_instance.id = "company_id"
    mock_company.return_value = mock_company_instance

    # Applicant mock
    mock_applicant_instance = MagicMock()
    mock_applicant_instance.details = {
        "personal_information": {"email": "candidate@example.com"}
    }
    mock_applicant.return_value = mock_applicant_instance

    # Integration credentials
    mock_integration.return_value.credentials = {
        "credentials": [
            {"service_type": "sendgrid", "api_key": "valid_key"}
        ]
    }

    # Zoom access token and meeting creation
    mock_validate_access.return_value = {"access_token": "zoom_token"}
    
    mock_create_meeting.return_value = {"join_url": "https://zoom.us/fake-meeting"}
    

    # Email template
    mock_template_instance = MagicMock()
    mock_template_instance.email_data = {"id": 1, "send_count": 5}
    mock_template.return_value = mock_template_instance


    payload = {
        "start_time": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
        "end_time": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
        "agenda": "Interview for Backend Role",
        "timezone": "Asia/Kolkata",
        "topic": "Backend Interview",  # ✅ Add this
        "settings": {
            "meeting_invitees": [{"email": "invitee@example.com"}]
        }
    }

    # Send POST request
    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.post(
            f"/api/v1/applicants/{applicant_uuid}/create-meeting",
            params={
            "end_time": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
            "from_address": "admin@persimmon.com",
            "interview_type": InterviewType.ONLINE.value,
            "platform_name": "zoom",
            },
            json=payload
        )
    
    # Assert expected results
    assert response.status_code == 201
    assert response.json()["data"]["join_url"] == "https://zoom.us/fake-meeting"


@pytest.mark.asyncio
@patch("app.helpers.email_helper.sendgrid_send_mail", return_value={"message":"Email sent successfully"})
@patch("app.helpers.email_helper.get_sendgrid_senders", return_value=["admin@persimmon.com"])
@patch("app.helpers.firebase_helper.verify_firebase_token", return_value={"email": "recruiter@example.com"})
@patch("app.db.session.get_db")
@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid")
@patch("app.models.company.Company.get_by_domain")
@patch("app.helpers.zoom_helper.create_meeting")
@patch("app.helpers.zoom_helper.validate_access_token")
@patch("app.helpers.email_helper.send_email", return_value="Email sent successfully")
@patch("app.helpers.regex_helper.get_domain_from_email", return_value="company.com")
@patch("app.helpers.date_helper.validate_future_datetime")
@patch("app.helpers.date_helper.calculate_duration_in_minutes", return_value=30)
@patch("app.models.integration.Integration.get_credentials")
@patch("app.models.template.Template.get_by_company_id")
async def test_create_meeting_integration_not_found(    
        mock_template,
        mock_integration,
        mock_duration,
        mock_date_validate,
        mock_domain,
        mock_send_email,
        mock_validate_access,
        mock_create_meeting,
        mock_company,
        mock_applicant,
        mock_get_db,
        mock_token,
        mock_senders,
        mock_sendgrid
    ) :
    # Setup test UUID
    applicant_uuid = uuid4()

    # Setup mock DB session
    mock_db = MagicMock()
    mock_get_db.return_value = iter([mock_db])

    # Company mock
    mock_company_instance = MagicMock()
    mock_company_instance.id = "company_id"
    mock_company.return_value = mock_company_instance

    # Applicant mock
    mock_applicant_instance = MagicMock()
    mock_applicant_instance.details = {
        "personal_information": {"email": "candidate@example.com"}
    }
    mock_applicant.return_value = mock_applicant_instance

    # Integration credentials
    mock_integration.return_value= None 

    # Zoom access token and meeting creation
    mock_validate_access.return_value = {"access_token": "zoom_token"}
    
    mock_create_meeting.return_value = {"join_url": "https://zoom.us/fake-meeting"}
    

    # Email template
    mock_template_instance = MagicMock()
    mock_template_instance.email_data = {"id": 1, "send_count": 5}
    mock_template.return_value = mock_template_instance


    payload = {
        "start_time": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
        "end_time": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
        "agenda": "Interview for Backend Role",
        "timezone": "Asia/Kolkata",
        "topic": "Backend Interview",  # ✅ Add this
        "settings": {
            "meeting_invitees": [{"email": "invitee@example.com"}]
        }
    }

    # Send POST request
    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.post(
            f"/api/v1/applicants/{applicant_uuid}/create-meeting",
            params={
            "end_time": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
            "from_address": "admin@persimmon.com",
            "interview_type": InterviewType.ONLINE.value,
            "platform_name": "zoom",
            },
            json=payload
        )
    
    # Assert expected results
    assert response.status_code == 404
    assert response.json()["detail"] == "Integration details not found"


@pytest.mark.asyncio
@patch("app.helpers.email_helper.sendgrid_send_mail", return_value={"message":"Email sent successfully"})
@patch("app.helpers.email_helper.get_sendgrid_senders", return_value=["admin@persimmon.com"])
@patch("app.helpers.firebase_helper.verify_firebase_token", return_value={"email": "recruiter@example.com"})
@patch("app.db.session.get_db")
@patch("app.api.v1.endpoints.applicants.Applicant.get_by_uuid")
@patch("app.models.company.Company.get_by_domain")
@patch("app.helpers.google_meet_helper.create_meeting")
@patch("app.helpers.google_meet_helper.validate_access_token")
@patch("app.helpers.email_helper.send_email", return_value="Email sent successfully")
@patch("app.helpers.regex_helper.get_domain_from_email", return_value="company.com")
@patch("app.helpers.date_helper.validate_future_datetime")
@patch("app.helpers.date_helper.calculate_duration_in_minutes", return_value=30)
@patch("app.models.integration.Integration.get_credentials")
@patch("app.models.template.Template.get_by_company_id")
async def test_create_google_meet_success(    
        mock_template,
        mock_integration,
        mock_duration,
        mock_date_validate,
        mock_domain,
        mock_send_email,
        mock_validate_access,
        mock_create_meeting,
        mock_company,
        mock_applicant,
        mock_get_db,
        mock_token,
        mock_senders,
        mock_sendgrid
    ) :
    # Setup test UUID
    applicant_uuid = uuid4()

    # Setup mock DB session
    mock_db = MagicMock()
    mock_get_db.return_value = iter([mock_db])

    # Company mock
    mock_company_instance = MagicMock()
    mock_company_instance.id = "company_id"
    mock_company.return_value = mock_company_instance

    # Applicant mock
    mock_applicant_instance = MagicMock()
    mock_applicant_instance.details = {
        "personal_information": {"email": "candidate@example.com"}
    }
    mock_applicant.return_value = mock_applicant_instance

    # Integration credentials
    mock_integration.return_value.credentials = {
        "credentials": [
            {"service_type": "sendgrid", "api_key": "valid_key"}
        ]
    }

    # Zoom access token and meeting creation
    mock_validate_access.return_value = {"access_token": "google_token"}
    
    mock_create_meeting.return_value = {"meeting_link": "https://google.meeet/fake-meeting"}
    

    # Email template
    mock_template_instance = MagicMock()
    mock_template_instance.email_data = {"id": 1, "send_count": 5}
    mock_template.return_value = mock_template_instance


    payload = {
        "start_time": (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat(),
        "end_time": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
        "agenda": "Interview for Backend Role",
        "timezone": "Asia/Kolkata",
        "topic": "Backend Interview",  # ✅ Add this
        "settings": {
            "meeting_invitees": [{"email": "invitee@example.com"}]
        }
      
    }

    # Send POST request
    async with AsyncClient(app=app, base_url="http://test") as ac:
        response = await ac.post(
            f"/api/v1/applicants/{applicant_uuid}/create-meeting",
            params={
            "end_time": (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat(),
            "from_address": "admin@persimmon.com",
            "interview_type": InterviewType.ONLINE.value,
            "platform_name": "google_meet",
            },
            json=payload
        )
    
    # Assert expected results
    assert response.status_code == 201
    assert response.json()["data"]["meeting_link"] == "https://google.meeet/fake-meeting"
    