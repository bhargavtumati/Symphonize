from fastapi import APIRouter, HTTPException, Form, File, Depends, UploadFile
from pydantic import ValidationError
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.Customization import Customization
from app.helpers import db_helper as dbh
from app.helpers.firebase_helper import verify_firebase_token
from app.api.v1.endpoints.models.customizerequest import CustomizationCreate
from app.utils.saveimage import save_image
import base64

router = APIRouter()

@router.post("/customizations/{domain}")
async def create_or_update_customizations(
    domain: str,
    enable_cover_photo: bool = Form(...),
    heading: str = Form(...),
    description: str = Form(...),
    dark_mode: bool = Form(...),
    color_selected: str = Form(...),
    font: str = Form(...),
    file: UploadFile = File(None),  # File upload field, optional
    token: dict = Depends(verify_firebase_token),
    session: Session = Depends(get_db),
):
    """
    Update or create customization settings for a user's career page based on the domain.
    """
    email = token.get("email")  # Extract the user's email from the token

    # Prepare the data to validate with CustomizationCreate
    form_data = {
        "domain": domain,
        "enable_cover_photo": enable_cover_photo,
        "heading": heading,
        "description": description,
        "dark_mode": dark_mode,
        "color_selected": color_selected,
        "font": font,
    }

    # Validate the data using the Pydantic model
    try:
        customization_data = CustomizationCreate(**form_data)  # Manually validate the form data
    except ValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    # Handle file upload if provided
    image_data = None
    if file:
        try:
            image_data = save_image(file, domain)
            if not image_data:
                raise ValueError("Image saving failed.")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error saving image: {str(e)}")

    # Fetch or initialize customization record
    customization = Customization.get_by_domain(session=session, domain=domain, email=email)

    try:
        # Update existing customization
        if customization:
            existing_colors = customization.settings.get("recently_used_colors", [])
            recently_used_colors = [color for color in [color_selected] + existing_colors if color.strip()]
            recently_used_colors = list(dict.fromkeys(recently_used_colors))[:10]

            # Prepare updated data
            updated_settings = {
                "domain": domain,
                "enable_cover_photo": customization_data.enable_cover_photo,
                "heading": customization_data.heading,
                "description": customization_data.description,
                "dark_mode": customization_data.dark_mode,
                "color_selected": customization_data.color_selected,
                "font": customization_data.font,
                "image_data": image_data and base64.b64encode(image_data).decode("latin1"),
                "recently_used_colors": recently_used_colors,
            }
            customization.settings.update(updated_settings)
            customization.meta.update(dbh.update_meta(customization.meta, token.get("email")))
            customization.update(session=session)

        # Create a new customization
        else:
            default_colors = [color_selected, "Red", "Yellow", "Blue", "Green", "Purple"]
            recently_used_colors = [color for color in [color_selected] + default_colors if color.strip()]
            recently_used_colors = list(dict.fromkeys(recently_used_colors))[:10]

            customization = Customization(
                settings={
                    "domain": domain,
                    "enable_cover_photo": customization_data.enable_cover_photo,
                    "heading": customization_data.heading,
                    "description": customization_data.description,
                    "dark_mode": customization_data.dark_mode,
                    "color_selected": customization_data.color_selected,
                    "font": customization_data.font,
                    "image_data": image_data and base64.b64encode(image_data).decode("latin1"),
                    "recently_used_colors": recently_used_colors,
                },
                meta=dbh.get_metadata(),
            )
            customization.create(session=session, created_by=token.get("email"))

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to update customization: {str(e)}")

    # Return the response with the customization data
    return {
        "message": "Customization successfully created or updated.",
        "data": customization.settings,
    }
